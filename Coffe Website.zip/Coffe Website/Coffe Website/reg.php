<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection
    include 'db_connection.php';

    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Perform validation and sanitization if needed

    // Insert user data into database
    $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
    if (mysqli_query($conn, $sql)) {
        // Registration successful
        header("Location: log.html"); // Redirect to login page after successful registration
        exit();
    } else {
        // Registration failed
        $error = "Registration failed. Please try again.";
    }
}
?>

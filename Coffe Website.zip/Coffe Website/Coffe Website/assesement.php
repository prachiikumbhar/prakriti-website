<?php
$dominantDosha = null;

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Define the questions and their corresponding dosha characteristics
    $questions = [
        'q1' => ['Thin', 'Medium', 'Broad'],
        'q2' => ['Low', 'Moderate', 'Overweight'],
        'q3' => ['Dry, Rough, Cracked', 'Soft, Thin, Tendency for Acnes & Freckles', 'Thick, Oily, Cool, Clear Complexion'],
        'q4' => ['Talkative', 'Sharp, Incisive Communication with Analytical Abilities', 'Less Vocal, with Good Communication Skill'],
        'q5' => ['Variable', 'Excessive', 'Scanty'],
        'q6' => ['Fearful, moody, unpredictable', 'Aggressive, Jealous, Impatience', 'Calm, Attached, Likeable'],
        'q7' => ['Cracked', 'Red', 'White coated'],
        'q8' => ['Brittle, Dry, Cracked', 'Soft, Pink', 'Thick, Strong, Shiny'],
        'q9' => ['Dry, Thin, Prone to Break', 'Soft, Early Greying', 'Thick, Oily'],
        'q10' => ['Quick, Responsive', 'Moderate understanding', 'Slow']
    ];

    // Initialize dosha scores
    $doshaScores = [
        'Vata' => 0,
        'Pitta' => 0,
        'Kapha' => 0
    ];

    // Loop through each question and update dosha scores based on the selected options
    foreach ($questions as $question => $options) {
        if (isset($_GET[$question])) {
            $selectedOption = $_GET[$question];
            switch ($selectedOption) {
                case $options[0]:
                    $doshaScores['Vata']++;
                    break;
                case $options[1]:
                    $doshaScores['Pitta']++;
                    break;
                case $options[2]:
                    $doshaScores['Kapha']++;
                    break;
            }
        }
    }

    // Determine the dominant dosha based on dosha scores
    $dominantDosha = array_keys($doshaScores, max($doshaScores))[0];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Phenotype Questionnaire</title>
  <style>
    * {
      padding: 0;
      margin: 0;
    }

    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-image: url("backimg.jpg");
      background-size: cover;
      background-repeat: no-repeat;
    }

    .container {
      width: 50%;
      margin-left: 10%;
      background-color: rgba(255, 255, 255, 0.8);
      padding: 20px;
      border-radius: 10px;
    }

    h1 {
      text-align: center;
    }

    .question {
      margin-bottom: 20px;
      text-align: left;
    }

    .question label {
      display: block;
      margin-bottom: 5px;
    }

    .submit-btn {
      display: block;
      width: 100%;
      padding: 10px;
      margin-top: 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .submit-btn:hover {
      width: calc(100% - 20px);
      padding: 10px;
      border-radius: 5px;
      border: 1px solid #633333;
    }

    .reset-btn {
      display: block;
      width: 100%;
      padding: 10px;
      margin-top: 20px;
      color: #199db7;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .reset-btn:hover {
      background-color: #33ccd6;
    }

    .result-container {
      display: <?php echo ($_SERVER["REQUEST_METHOD"] == "GET") ? 'block' : 'none'; ?>;
    }
  </style>
</head>

<body>
  <main>
    <div class="container">
      <h1>Prakriti Assessment !!</h1>
      <p>Move forward and continue the process to know about your Prakriti...</p>

      <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get">

        <div class="question">
          <label for="question1">Question 1: How is your body frame?</label><br>
          <input type="radio" id="thin" option value="Thin" name="q1">Thin</option><br>
          <input type="radio" id="medium" option value="Medium" name="q1">Medium</option><br>
          <input type="radio" id="broad" option value="Broad" name="q1">Broad</option><br>
        </div>
        <div class="question">
          <label for="question2">Question 2: How is your body weight?</label><br>
          <input type="radio" id="low" option value="low" name="q2">low</option><br>
          <input type="radio" id="moderate" option value="moderate" name="q2">moderate</option><br>
          <input type="radio" id="over_weight" option value="over weight" name="q2">over weight</option><br>
        </div>
        <div class="question">
          <label for="question3">Question 3: How is your skin?</label><br>
          <input type="radio" id="Dry, Rough, Cracked" option value="Dry, Rough, Cracked" name="q3">Dry, Rough, Cracked</option><br>
          <input type="radio" id="Soft, Thin, Tendency for Acnes & Freckles" option value="Soft, Thin, Tendency for Acnes & Freckles" name="q3">Soft, Thin, Tendency for Acnes & Freckles</option><br>
          <input type="radio" id="Thick, Oily, Cool, Clear Complexion" option value="Thick, Oily, Cool, Clear Complexion" name="q3">Thick, Oily, Cool, Clear Complexion</option><br>
        </div>
        <div class="question">
          <label for="question4">Question 4: How is your communication?</label><br>
          <input type="radio" id="Talkative" option value="Talkative" name="q4">Talkative</option><br>
          <input type="radio" id="Sharp, Incisive Communication with Analytical Abilities" option value="Sharp, Incisive Communication with Analytical Abilities" name="q4">Sharp, Incisive Communication with Analytical Abilities</option><br>
          <input type="radio" id="Less Vocal, with Good Communication Skill" option value="Less Vocal, with Good Communication Skill" name="q4">Less Vocal, with Good Communication Skill</option><br>
        </div>
        <div class="question">
          <label for="question5">Question 5: How is your thirst?</label><br>
          <input type="radio" id="Variable" option value="Variable" name="q5">Variable</option><br>
          <input type="radio" id="Excessive" option value="Excessive" name="q5">Excessive</option><br>
          <input type="radio" id="Scanty" option value="Scanty" name="q5">Scanty</option><br>
        </div>
        <div class="question">
          <label for="question6">Question 6: How is your emotional temperament?</label><br>
          <input type="radio" id="Fearful, moody, unpredictable" option value="Fearful, moody, unpredictable" name="q6">Fearful, moody, unpredictable</option><br>
          <input type="radio" id="Aggressive, Jealous, Impatience" option value="Aggressive, Jealous, Impatience" name="q6">Aggressive, Jealous, Impatience</option><br>
          <input type="radio" id="Calm, Attached, Likeable" option value="Calm, Attached, Likeable" name="q6">Calm, Attached, Likeable</option><br>
        </div>
        <div class="question">
          <label for="question7">Question 7: How is your tongue?</label><br>
          <input type="radio" id="Cracked" option value="Cracked" name="q7">Cracked</option><br>
          <input type="radio" id="Red" option value="Red" name="q7">Red</option><br>
          <input type="radio" id="White coated" option value="White coated" name="q7">White coated</option><br>
        </div>
        <div class="question">
          <label for="question8">Question 8: How are your nails?</label><br>
          <input type="radio" id="Brittle, Dry, Cracked" option value="Brittle, Dry, Cracked" name="q8">Brittle, Dry, Cracked</option><br>
          <input type="radio" id="Soft, Pink" option value="Soft, Pink" name="q8">Soft, Pink</option><br>
          <input type="radio" id="Thick, Strong, Shiny" option value="Thick, Strong, Shiny" name="q8">Thick, Strong, Shiny</option><br>
        </div>
        <div class="question">
          <label for="question9">Question 9: How are your hair?</label><br>
          <input type="radio" id="Dry, Thin, Prone to Break" option value="Dry, Thin, Prone to Break" name="q9">Dry, Thin, Prone to Break</option><br>
          <input type="radio" id="Soft, Early Greying" option value="Soft, Early Greying" name="q9">Soft, Early Greying</option><br>
          <input type="radio" id="Thick, Oily" option value="Thick, Oily" name="q9">Thick, Oily</option><br>
        </div>
        <div class="question">
          <label for="question10">Question 10: How are your initiation capabilities?</label><br>
          <input type="radio" id="Quick, Responsive" option value="Quick, Responsive" name="q10">Quick, Responsive</option><br>
          <input type="radio" id="Moderate understanding" option value="Moderate understanding" name="q10">Moderate understanding</option><br>
          <input type="radio" id="Slow" option value="Slow" name="q10">Slow</option><br>
        </div>

        <button class="submit-btn" type="submit">Submit</button>
        <button class="reset-btn" type="reset">Reset</button>
      </form>

      <div class="result-container">
        <?php if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($dominantDosha)) : ?>
          <h1>Result</h1>
          <p>Your dominant dosha is: <?php echo $dominantDosha; ?></p>
        <?php endif; ?>
      </div>

    </div>
  </main>
</body>

</html>

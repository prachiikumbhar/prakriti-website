<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        // Authentication successful, redirect to dashboard or home page
        $_SESSION['email'] = $email;
        header("Location: index.html");
        exit();
    } else {
        header('Location: log.html');
        exit;
    }
}
?>
